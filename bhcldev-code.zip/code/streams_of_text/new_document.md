This is *really* important text with *really* important words.

* These words are not important.
* Neither are these.

You can *always* tell really important text because it's in italics
