Here are a few interesting links:
LINKS
I hope you find them useful.
